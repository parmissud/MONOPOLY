package MONOPOLY;
public class House extends Property {
    public House(String name, Player player) {
        super(name, player);
    }
}
