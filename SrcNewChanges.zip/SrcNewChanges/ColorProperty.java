package MONOPOLY;

public class ColorProperty extends Property{

}
