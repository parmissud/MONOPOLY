package MONOPOLY;

public class Square {

    protected int index;
    private final String name;
    public Square(String name){
        this.name = name;
    }
}
