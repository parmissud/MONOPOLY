package MONOPOLY;

public class Hotel extends Property {
    public Hotel(String name , Player player) {
        super(name, player);
    }
}
