public class Jail extends NonCash {
    public Jail(String name, Player player) {
        super(name, player);
    }
}
