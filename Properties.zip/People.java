public class People {
    Cash cashPossessions;
    //NonCash nonCashPossessions;
    Cinema[] cinemas = new Cinema[3];
    Fields[] fields = new Fields[8];
}
