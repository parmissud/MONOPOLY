public class Hotel extends NonCash {
    public Hotel(String name , Player player) {
        super(name, player);
    }
}
