public abstract class Properties {
}
