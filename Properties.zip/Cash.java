public class Cash extends Properties {
    private double money;
    public Cash(){
        money = 1500;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }
}
