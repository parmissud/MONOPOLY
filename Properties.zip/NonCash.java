public class NonCash extends Properties {
    private int rent;
    private Player player;
    private final String name;
    public NonCash(String name, Player player) {
        this.name = name;
        this.player = player;
    }

    public void setRent(int rent) {
        this.rent = rent;
    }

    public int getRent() {
        return rent;
    }

    public String getName() {
        return name;
    }

    public Player getPlayer() {
        return player;
    }

    public void withdrawMoney(double amount) {
        double oldMoney = player.cashPossessions.getMoney();
        player.cashPossessions.setMoney(oldMoney - amount);
    }
}
