public class House extends NonCash {
    public House(String name, Player player) {
        super(name, player);
    }
}
