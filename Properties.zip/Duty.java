public class Duty extends NonCash {
    public Duty(String name, Player player) {
        super(name, player);
        withdrawMoney(0.1*player.cashPossessions.getMoney());
    }
}
