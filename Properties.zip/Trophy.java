public class Trophy extends NonCash {
    public Trophy(String name, Player player) {
        super(name, player);
        withdrawMoney(-200);
    }
}
