public class Banker extends People {
    static Airport[] airports = new Airport[3];
    static Cinema[] cinemas = new Cinema[3];
    static Fields[] utilities = new Fields[8];
}
