public class Railroad extends NonCash {
    public Railroad(String name, Player player) {
        super(name, player);
        setRent(100);
    }
}
