public class Airport extends NonCash{
    private int id;
    private Player player;
    public Airport(Player player) {
        this.player = player;
    }
    void fly() {
        player.cashPossessions.money -= 50;
        player.move.toStep(id+1);
    }
}
