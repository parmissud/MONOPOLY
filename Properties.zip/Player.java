public class Player extends People {
    public Player() {
        cashPossessions.money = 1500;
    }
    Move move;
    Fields[] utilities = new Fields[8];
    Cinema[] cinemas = new Cinema[3];
    void property() {

    }
}
