public class Move {
    public void nextStep() {

    }
    public void toStep(int index) {

    }
}
