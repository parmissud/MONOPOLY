public class Random extends NonCash {
    public Random(String name, Player player) {
        super(name, player);
    }
}
